import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  /*Falta implementar los @Input y @Output*/

  constructor() { }

  ngOnInit() {
  }

  verificar(e:string){
    console.log(e);
  }


}

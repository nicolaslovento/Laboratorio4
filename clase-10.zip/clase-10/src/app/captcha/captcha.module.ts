import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RecaptchaModule, RecaptchaFormsModule } from 'ng-recaptcha';
import { CaptchaComponent } from './captcha.component';

@NgModule({
  declarations: [CaptchaComponent],
  imports: [
    CommonModule,
    RecaptchaModule,
    RecaptchaFormsModule
  ],exports:[CaptchaComponent]
})
export class CaptchaModule { }

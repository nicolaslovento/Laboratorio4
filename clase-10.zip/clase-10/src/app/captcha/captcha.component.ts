import { Component, OnInit,Output } from '@angular/core';
import { EventEmitter } from 'events';

@Component({
  selector: 'mi-captcha',
  templateUrl: './captcha.component.html',
  styleUrls: ['./captcha.component.css']
})
export class CaptchaComponent implements OnInit {
  @Output() data : string;
  constructor() { }

  ngOnInit() {
  }

  resolved(captchaResponse: string) {
    //console.log(`Resolved captcha with response: ${captchaResponse}`);
    this.data=captchaResponse;
  }

}

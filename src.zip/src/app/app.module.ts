import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PagesModule } from './pages/pages.module';
import {AngularFirestoreModule} from '@angular/fire/firestore';
import {AngularFireModule } from '@angular/fire';

const firebaseConfig = {
  apiKey: "AIzaSyD8cNhw8IqgskXUkyn8CabPGDkIOMg1H_8",
  authDomain: "clase5-17348.firebaseapp.com",
  databaseURL: "https://clase5-17348.firebaseio.com",
  projectId: "clase5-17348",
  storageBucket: "clase5-17348.appspot.com",
  messagingSenderId: "512081674502",
  appId: "1:512081674502:web:9ae21b83567c8b92431e87"
};
@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    PagesModule,
    AngularFirestoreModule,
    AngularFireModule.initializeApp(firebaseConfig)
  ],
  providers: [],
  bootstrap: [AppComponent, ]
})
export class AppModule { }
